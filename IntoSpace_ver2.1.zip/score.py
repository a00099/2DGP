from pico2d import *
from coin import *
from collide import *
from roket import *


class Score:
    def __init__(self):
        self.x,self.x2,self.x3,self.x4 =580, 570, 560, 550
        self.eatcount =0
        self.drawOn = 0
        self.frameupdatetime = 0
        self.frame, self.frame2, self.frame3, self.frame4 = 0,0,0,0
        self.f1,self.f2,self.f3,self.f4 = 0,0,0,0
        self.numcount = 0
        self.on = 0
        self.image = load_image('numFont.png')
        self.scoreimage = load_image('score2.png')

    def update(self):
        self.frameupdatetime += 1
        if self.frameupdatetime % 100 == 0:
            self.frame = (self.frame + 1) % 10
        if self.frameupdatetime % 1000 == 0:
            self.frame2 = (self.frame2 + 1) % 10
        if self.frameupdatetime % 10000 == 0:
            self.frame3 = (self.frame3 + 2) % 10
        if self.frameupdatetime % 100000 == 0:
            self.frame4 = (self.frame4 + 4) % 10

    def eat(self):
        self.frame2 += 1
        self.eatcount += 1
        if self.eatcount % 9 == 0:
            self.frame3 += 1
            self.frame2 = 0
        elif self.eatcount % 99 == 0:
            self.frame4 += 1
            self.frame3 = 0
            self.frame2 = 0

    def save_data(self):
        self.f1,self.f2,self.f3,self.f4 =self.frame, self.frame2, self.frame3, self.frame4

    def result_score(self):
        self.image.clip_draw(self.frame * 10, 0, 10, 15, 360,385)
        self.image.clip_draw(self.frame2 * 10, 0, 10, 15, 350,385)
        self.image.clip_draw(self.frame3 * 10, 0, 10, 15, 340, 385)
        self.image.clip_draw(self.frame4 * 10, 0, 10, 15, 330, 385)

    def draw(self):
        self.scoreimage.draw(500, 680)
        self.image.clip_draw(self.frame * 10, 0, 10, 15, self.x,680)
        self.image.clip_draw(self.frame2 * 10, 0, 10, 15, self.x2,680)
        self.image.clip_draw(self.frame3 * 10, 0, 10, 15, self.x3, 680)
        self.image.clip_draw(self.frame4 * 10, 0, 10, 15, self.x4, 680)
