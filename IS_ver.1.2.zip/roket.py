#__author__ = 'JU'

import random

from pico2d import *


class Rocket:
    image = None
    stop_image= None

    def __init__(self):
        self.x, self.y = 300, 90
        self.frame = 0
        self.dir = 1
        self.Rstate = 0
        self.Lstate = 0
        self.Ustate = 0
        self.Dstate = 0
        if Rocket.stop_image == None:
            self.stop_image = load_image('rocket_stop.png')
        if Rocket.image == None:
            self.image = load_image('rocket_animation.png')

    def update(self):
        self.frame = (self.frame + 1) % 2
        if self.Lstate == 1:
            if self.x > 27:
                self.x -= 2
        if self.Rstate == 1:
            if self.x < 573:
                self.x +=2
        if self.Ustate == 1:
            if self.y < 655:
                self.y +=2
        if self.Dstate == 1:
            if self.y > 45:
                self.y -=2

    def draw(self):
        if self.Lstate == 0 and self.Rstate == 0 and self.Ustate == 0:
            self.image.clip_draw(2* 60, 0, 60, 89, self.x, self.y)
        else:
            self.image.clip_draw(self.frame * 60, 0, 60, 89, self.x, self.y)

    def get_bb(self):
        return self.x-27,self.y-44,self.x+27,self.y+45

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def handle_event(self,event):
        if event.type == SDL_KEYDOWN:
            if event.key == SDLK_LEFT:                self.Lstate = 1
            if event.key == SDLK_RIGHT:                self.Rstate = 1
            if event.key == SDLK_UP:                self.Ustate = 1
            if event.key == SDLK_DOWN:                self.Dstate = 1
        if event.type == SDL_KEYUP:
            if event.key == SDLK_LEFT:
                self.Lstate = 0
            if event.key == SDLK_RIGHT:
                self.Rstate = 0
            if event.key == SDLK_UP:
                self.Ustate = 0
            if event.key == SDLK_DOWN:
                self.Dstate = 0
