#__author__ = 'JU'

import main_state
import game_framework
from pico2d import *
from score import *
from bgm import *

name = "ResultState"
image = None
image2 = None
imagecount = 0
#score = None

def enter():
    global image,image2,imagecount,score
    #score = Score()
    #open_canvas(600,700)
    image = load_image('resouce/result.png')
    image2 = load_image('resouce/result2.png')


def exit():
    global image,image2,score
    del(image)
    del(image2)
    #del(score)


def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if(event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
                game_framework.quit()
            elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
                game_framework.change_state(main_state)


def draw():
    global image,image2
    clear_canvas()
    if imagecount % 200 < 100:
       image.draw(300,350)
    else:
        image2.draw(300,350)
    main_state.score.result_score()
    #main_state.score.draw()
    update_canvas()


def update():
    global imagecount
    #print("%d, %d"%(main_state.score.frame, main_state.score.frame2))
    imagecount += 1

def pause():
    pass


def resume():
    pass






