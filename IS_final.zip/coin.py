import random

from pico2d import *

class Coin:
    image = None

    def __init__(self):
        self.x, self.y = random.randint(0, 600),random.randint(800, 1400)
        self.state = 0
        self.levelcount =0
        if self.image == None:
            self.image = load_image('resouce/money_gold.png')

    def update(self):
        if self.state == 1:
            if self.state == 1:
                self.levelcount += 1
                if self.levelcount< 1000:
                    self.y -= 2
                elif 1000<= self.levelcount and self.levelcount< 2000:
                    self.y -=4
                else:
                    self.y -= 6

    def draw(self):
        self.image.draw(self.x,self.y)

    def get_bb(self):
        return self.x-18,self.y-18,self.x+18,self.y+18

    def draw_bb(self):
        draw_rectangle(*self.get_bb())