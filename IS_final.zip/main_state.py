import random
import math

from pico2d import *

import game_framework
import title_state
import result_state

from collide import *
from roket import Rocket
from obstacle import *
from background import Sky,Grass
from score import Score
from coin import Coin
from bgm import Main

name = "MainState"

sky = None
bomb = None
rocket = None
plane = None
grass = None
font = None
heli = None
score = None
coins = None
hitdraw = 0
main_bgm = None

def enter():
    global grass,sky,rocket,plane,planes,heli,score,hitdraw,coins,main_bgm,bomb,scorecount
    sky = Sky()
    rocket = Rocket()
    grass = Grass()
    plane = Plane()
    bomb = Bomb()
    heli = Helicopter()
    score = Score()
    coins = [Coin() for i  in range(10)]
    main_bgm = Main()
    hitdraw = 1
    scorecount = 0

def exit():
    global grass,sky,rocket,plane,heli,coins,main_bgm,bomb
    del(sky)
    del(rocket)
    del(grass)
    del(plane)
    del(heli)
    del(coins)
    del(main_bgm)
    del(bomb)


def pause():
    pass

def resume():
    pass

def handle_events():
    global hitdraw
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
                game_framework.change_state(title_state)
            else:
                rocket.handle_event(event)
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_h):
                if hitdraw == 0:
                    hitdraw = 1
                else:
                    hitdraw = 0
        if event.type == SDL_KEYDOWN:
            grass.state = 1
            sky.state =1
            plane.state = 1
            heli.state = 1
            bomb.state = 1
            for coin in coins:
                coin.state = 1
            score.on = 1

def update():
    global scorecount
    if grass.state == 1:
        scorecount+=1
    rocket.update()
    plane.update()
    sky.update()
    grass.update()
    heli.update()
    bomb.update()
    for coin in coins:
        coin.update()
    for coin in coins:
        if collide(coin, rocket):
            score.frameupdatetime += 10
            coins.remove(coin)
            rocket.eat(coin)
            score.eat()
    if score.on == 1:
        score.update()
    if collide(heli,rocket) or collide(plane,rocket) or collide(bomb,rocket):
        #score.save_data()
        game_framework.change_state(result_state)
    if  scorecount % 300 == 299:
        scorecount = 0
        for i in range(0,10):
            tcoin=Coin()
            coins.append(tcoin)

def draw():
    global hitdraw
    clear_canvas()
    sky.draw()
    grass.draw()
    rocket.draw()
    plane.draw()
    heli.draw()
    score.draw()
    bomb.draw()
    for coin in coins:
        coin.draw()

    if hitdraw == 0:
        plane.draw_bb()
        rocket.draw_bb()
        heli.draw_bb()
        coin.draw_bb()
        bomb.draw_bb()
        for coin in coins:
            coin.draw_bb()

    update_canvas()






