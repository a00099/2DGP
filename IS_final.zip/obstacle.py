#__author__ = 'JU'

from pico2d import *
from collide import *

import random

class Plane:
    image = None

    def __init__(self):
        self.state = 0
        self.levelcount =0
        self.x, self.y = 650,random.randint(500,650)
        if Plane.image == None:
            self.image = load_image('resouce/plane.png')

    def update(self):
        if self.state == 1:
            self.levelcount += 1
            if self.levelcount < 1000:
                self.y -= 1
                if self.x < - 150:
                    self.x, self.y = random.randint(650,750),random.randint(550,750)
                else:
                    self.x -= 3
            elif 1000 <= self.levelcount and self.levelcount <= 3000:
                self.y -= 2.4
                if self.x < - 50:
                    self.x, self.y = random.randint(650,750),random.randint(700,1000)
                else:
                    self.x -= 4
            else:
                self.y -= 4.0
                if self.x < - 50:
                    self.x, self.y = random.randint(650,750),random.randint(700,1000)
                else:
                    self.x -= 6

    def draw(self):
        self.image.draw(self.x,self.y)

    def get_bb(self):
        return self.x-55,self.y-30,self.x+50,self.y+30

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

class Helicopter:
    image = None
    image2 = None

    def __init__(self):
        self.flag = 0
        self.state = 0
        self.anicount =0
        self.levelcount =0
        self.x, self.y = -100, random.randint(500,750)
        self.image = load_image('resouce/heli1.png')
        self.image2 = load_image('resouce/heli2.png')

    def update(self):
        if self.state != 0:
            self.levelcount +=1
            if self.levelcount > 1500:
                self.state = 2
                if self.state == 2:
                    self.anicount += 1
                    if 1500 <= self.levelcount and self.levelcount < 2500:
                        self.y -= 2
                        if self.x > 800:
                            self.x = -100
                            self.y = random.randint(600,1000)
                        else:
                            self.x += 3
                    elif 2500 <= self.levelcount and self.levelcount < 5000:
                        self.y -= 3
                        if self.x > 800:
                            self.x = -100
                            self.y = random.randint(550,1100)
                        else:
                            self.x += 4.2
                    else:
                        self.y -= 6.0
                        if self.x > 800:
                            self.x = -100
                            self.y = random.randint(500,1200)
                        else:
                            self.x += 7
    def draw(self):
        if self.levelcount > 1500:
            if self.anicount % 20 < 10:
                self.image.draw(self.x,self.y)
            else:
                self.image2.draw(self.x,self.y)

    def get_bb(self):
         return self.x-50,self.y-35,self.x+50,self.y+35

    def draw_bb(self):
        if self.levelcount > 1500:
            draw_rectangle(*self.get_bb())


class Bomb:
    image = None

    def __init__(self):
        self.state = 0
        self.levelcount =0
        self.x, self.y = random.randint(50,650), 900
        if Plane.image == None:
            self.image = load_image('resouce/Bomb.png')

    def update(self):
        if self.state != 0:
            self.levelcount +=1
            if self.levelcount > 2500:
                self.state = 2
                if self.state == 2:
                    if 2500 <= self.levelcount and self.levelcount < 3500:
                        if self.y < -100:
                            self.x = random.randint(50,650)
                            self.y = 1300
                        else:
                            self.y -= 4
                    elif 3500 <= self.levelcount and self.levelcount < 4500:
                        if self.y < -100:
                            self.x = random.randint(50,650)
                            self.y = 1300
                        else:
                            self.y -= 8
                    else:
                        if self.y < -100:
                            self.x = random.randint(50,650)
                            self.y = 1300
                        else:
                            self.y -= 12.0

    def draw(self):
        if self.levelcount > 2500:
            self.image.draw(self.x,self.y)

    def get_bb(self):
        return self.x-45,self.y-45,self.x+45,self.y+45

    def draw_bb(self):
        if self.levelcount > 2500:
            draw_rectangle(*self.get_bb())


