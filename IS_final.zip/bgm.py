__author__ = 'JU'

from pico2d import *

class Main:
    def __init__(self):
        self.bgm = load_music('resouce/bgm.mp3')
        self.bgm.set_volume(50)
        self.bgm.repeat_play()

    def update(self):
        pass
    def draw(self):
        pass

class Title:
    def __init__(self):
        self.bgm = load_music('resouce/titlebgm.mp3')
        self.bgm.set_volume(50)
        self.bgm.repeat_play()

    def update(self):
        pass
    def draw(self):
        pass