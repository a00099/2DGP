# __author__ = 'JU'

from pico2d import *

class Sky:
    image1 = None
    image2 = None

    def __init__(self):
        if Sky.image1 == None:
            self.image1 = load_image('resouce/sky3.png')
        if Sky.image2 == None:
            self.image2 = load_image('resouce/sky3.png')
        self.levelcount = 0
        self.y = 400
        self.y2 = 1200
        self.state = 0

    def update(self):
        if self.state == 1:
            self.levelcount += 1
            if self.levelcount< 1000:
                if self.y < -400:
                    self.y = 1200
                else:
                    self.y -= 2
                if self.y2 < -400:
                    self.y2 = 1200
                else:
                    self.y2 -= 2
            elif 1000<= self.levelcount and self.levelcount< 2000:
                if self.y < -400:
                    self.y = 1200
                else:
                    self.y -= 4
                if self.y2 < -400:
                    self.y2 = 1200
                else:
                    self.y2 -= 4
            else:
                if self.y < -400:
                    self.y = 1200
                else:
                    self.y -= 6
                if self.y2 < -400:
                    self.y2 = 1200
                else:
                    self.y2 -= 6

    def draw(self):
        self.image1.draw(300,self.y)
        self.image2.draw(300,self.y2)


class Grass:
    def __init__(self):
        self.image = load_image('resouce/grass.png')
        self.y = 47
        self.state = 0

    def update(self):
        if self.state == 1:
            if(self.y > -50):
               self.y -=2

    def draw(self):
        self.image.draw(300, self.y)