import random
import math

from pico2d import *

import game_framework
import title_state


name = "MainState"

sky = None
rocket = None
plane = None
grass = None
font = None

class Plane:
    image = None
    image2 = None

    def __init__(self):
        self.state = 0
        self.x, self.y = random.randint(50,250), random.randint(500,750)
        self.x2, self.y2 = random.randint(350,550), random.randint(500,750)
        if Plane.image == None:
            self.image = load_image('plane.png')
        if Plane.image == None:
            self.image2 = load_image('plane.png')

    def update(self):
        if self.state == 1:
            if self.y < -100:
                self.x = random.randint(50,250)
                self.y = random.randint(1000,1200)
            else:
                self.y -= 2
            if self.y2 < -100:
                self.x2 = random.randint(350,550)
                self.y2 = random.randint(1000,1200)
            else:
                self.y2 -= 2

    def draw(self):
        self.image.draw(self.x,self.y)
        self.image2.draw(self.x2,self.y2)

class Rocket:
    image = None
    stop_image= None

    def __init__(self):
        self.x, self.y = 300, 90
        self.frame = 0
        self.dir = 1
        self.state = 0
        if Rocket.stop_image == None:
            self.stop_image = load_image('rocket_stop.png')
        if Rocket.image == None:
            self.image = load_image('rocket_animation.png')

    def update(self):
        self.frame = (self.frame + 1) % 2
        if self.state == 1:            self.x -= 2
        if self.state == 2:            self.x +=2
        if self.state == 3:            self.y +=2
        if self.state == 4:            self.y -=2

    def draw(self):
        if self.state == 0:
            self.image.clip_draw(2* 60, 0, 60, 89, self.x, self.y)
        else:
            self.image.clip_draw(self.frame * 60, 0, 60, 89, self.x, self.y)



class Sky:
    image1 = None
    image2 = None

    def __init__(self):
        if Sky.image1 == None:
            self.image1 = load_image('sky3.png')
        if Sky.image2 == None:
            self.image2 = load_image('sky3.png')
        self.y = 400
        self.y2 = 1200
        self.state = 0

    def update(self):
        if self.state == 1:
            if self.y == -400:
                self.y = 1200
            else:
                self.y -= 2

            if self.y2 == -400:
                self.y2 = 1200
            else:
                self.y2 -= 2
    def draw(self):
        self.image1.draw(300,self.y)
        self.image2.draw(300,self.y2)

class Grass:
    def __init__(self):
        self.image = load_image('grass_R.png')
        self.y = 47
        self.state = 0

    def update(self):
        if self.state == 1:
            if(self.y > -50):
               self.y -=2

    def draw(self):
        self.image.draw(300, self.y)

def enter():
    global grass,sky,rocket,plane,planes
    sky = Sky()
    rocket = Rocket()
    grass = Grass()
    plane = Plane()

def exit():
    global grass,sky,rocket,plane
    del(sky)
    del(rocket)
    del(grass)
    del(plane)

def pause():
    pass

def resume():
    pass

def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        if event.type == SDL_KEYDOWN:
            grass.state = 1
            sky.state =1
            plane.state = 1
            if event.key == SDLK_a:                rocket.state = 1
            if event.key == SDLK_d:                rocket.state = 2
            if event.key == SDLK_w:                rocket.state = 3
            if event.key == SDLK_s:                rocket.state = 4
        if event.type == SDL_KEYUP:
            if event.key == SDLK_a or event.key == SDLK_d or event.key == SDLK_w or event.key == SDLK_s:
                rocket.state = 0

        if math.sqrt((rocket.x - plane.x)*(rocket.x - plane.x) + (rocket.y - plane.y)*(rocket.y - plane.y))<110:
            game_framework.push_state(title_state)
        if math.sqrt((rocket.x - plane.x2)*(rocket.x - plane.x2) + (rocket.y - plane.y2)*(rocket.y - plane.y2))<110:
            game_framework.push_state(title_state)






def update():
    rocket.update()
    plane.update()
    sky.update()
    grass.update()


def draw():
    clear_canvas()
    sky.draw()
    grass.draw()
    rocket.draw()
    plane.draw()
    update_canvas()





