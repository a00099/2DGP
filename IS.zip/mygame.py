import game_framework

import start_state

game_framework.run(start_state)