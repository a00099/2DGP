import random
import math

from pico2d import *

import game_framework
import title_state
import result_state

from collide import *
from roket import Rocket
from obstacle import Plane,Helicopter
from background import Sky,Grass
from score import Score
from coin import Coin
from bgm import Main

name = "MainState"

sky = None
rocket = None
plane = None
grass = None
font = None
heli = None
score = None
coins = None
hitdraw = 0
main_bgm = None

def enter():
    global grass,sky,rocket,plane,planes,heli,score,hitdraw,coins,main_bgm
    sky = Sky()
    rocket = Rocket()
    grass = Grass()
    plane = Plane()
    heli = Helicopter()
    score = Score()
    coins = [Coin() for i  in range(100)]
    main_bgm = Main()
    hitdraw = 1

def exit():
    global grass,sky,rocket,plane,heli,coins,main_bgm
    del(sky)
    del(rocket)
    del(grass)
    del(plane)
    del(heli)
    del(coins)
    del(main_bgm)

def pause():
    pass

def resume():
    pass

def handle_events():
    global hitdraw
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        else:
            if event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
                game_framework.change_state(title_state)
            else:
                rocket.handle_event(event)
            if (event.type, event.key) == (SDL_KEYDOWN, SDLK_h):
                if hitdraw == 0:
                    hitdraw = 1
                else:
                    hitdraw = 0
        if event.type == SDL_KEYDOWN:
            grass.state = 1
            sky.state =1
            plane.state = 1
            heli.state = 1
            for coin in coins:
                coin.state = 1
            score.on = 1

def update():
    rocket.update()
    plane.update()
    sky.update()
    grass.update()
    heli.update()
    for coin in coins:
        coin.update()
    for coin in coins:
        if collide(coin, rocket):
            score.frameupdatetime += 10
            coins.remove(coin)
            rocket.eat(coin)
            score.eat()
    if score.on == 1:
        score.update()
    if collide(heli,rocket) or collide(plane,rocket):
        score.save_data()
        game_framework.change_state(result_state)

def draw():
    global hitdraw
    clear_canvas()
    sky.draw()
    grass.draw()
    rocket.draw()
    plane.draw()
    heli.draw()
    score.draw()
    for coin in coins:
        coin.draw()

    if hitdraw == 0:
        plane.draw_bb()
        rocket.draw_bb()
        heli.draw_bb()
        coin.draw_bb()
        for coin in coins:
            coin.draw_bb()

    update_canvas()






