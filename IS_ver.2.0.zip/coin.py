import random

from pico2d import *

class Coin:
    image = None

    def __init__(self):
        self.x, self.y = random.randint(0, 600),random.randint(700, 10000)
        self.state = 0
        if self.image == None:
            self.image = load_image('money_gold.png')

    def update(self):
        if self.state == 1:
            self.y -= 1

    def draw(self):
        self.image.draw(self.x,self.y)

    def get_bb(self):
        return self.x-18,self.y-18,self.x+18,self.y+18

    def draw_bb(self):
        draw_rectangle(*self.get_bb())