# __author__ = 'JU'

from pico2d import *

class Sky:
    image1 = None
    image2 = None

    def __init__(self):
        if Sky.image1 == None:
            self.image1 = load_image('sky3.png')
        if Sky.image2 == None:
            self.image2 = load_image('sky3.png')
        self.y = 400
        self.y2 = 1200
        self.state = 0

    def update(self):
        if self.state == 1:
            if self.y == -400:
                self.y = 1200
            else:
                self.y -= 1

            if self.y2 == -400:
                self.y2 = 1200
            else:
                self.y2 -= 1

    def draw(self):
        self.image1.draw(300,self.y)
        self.image2.draw(300,self.y2)


class Grass:
    def __init__(self):
        self.image = load_image('grass.png')
        self.y = 47
        self.state = 0

    def update(self):
        if self.state == 1:
            if(self.y > -50):
               self.y -=2

    def draw(self):
        self.image.draw(300, self.y)