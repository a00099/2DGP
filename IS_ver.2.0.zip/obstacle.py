#__author__ = 'JU'

from pico2d import *
from collide import *

import random

class Plane:
    image = None

    def __init__(self):
        self.state = 0
        self.levelcount =0
        self.x, self.y = random.randint(450,650), random.randint(500,750)
        if Plane.image == None:
            self.image = load_image('plane.png')

    def update(self):
        self.levelcount += 1
        if self.state == 1:
            if self.levelcount < 2000:
                self.y -= 1
                if self.x < - 200:
                    self.x, self.y = random.randint(550,650),random.randint(500,1200)
                else:
                    self.x -= 1
            elif 2000 <= self.levelcount and self.levelcount <= 4000:
                self.y -= 1.4
                if self.x < - 50:
                    self.x, self.y = random.randint(550,650),random.randint(500,1200)
                else:
                    self.x -= 1.4
            else:
                self.y -= 2.0
                if self.x < - 50:
                    self.x, self.y = random.randint(550,650),random.randint(500,1200)
                else:
                    self.x -= 1.6

    def draw(self):
        self.image.draw(self.x,self.y)

    def get_bb(self):
        return self.x-55,self.y-30,self.x+50,self.y+30

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

class Helicopter:
    image = None
    image2 = None

    def __init__(self):
        self.flag = 0
        self.state = 0
        self.anicount =0
        self.levelcount =0
        self.x, self.y = random.randint(-50,50), random.randint(500,750)
        self.image = load_image('heli1.png')
        self.image2 = load_image('heli2.png')

    def update(self):
        self.levelcount +=1
        if self.state == 1:
            if self.levelcount > 2000:
                self.anicount += 1
                if 1000 <= self.levelcount and self.levelcount < 2000:
                    self.y -= 1
                    if self.x > 800:
                        self.x = random.randint(-50,50)
                        self.y = random.randint(500,1200)
                    else:
                        self.x += 0.7
                elif 2000 <= self.levelcount and self.levelcount < 5000:
                    self.y -= 1.3
                    if self.x > 800:
                        self.x = random.randint(-50,50)
                        self.y = random.randint(500,1200)
                    else:
                        self.x += 1.4
                else:
                    self.y -= 2.0
                    if self.x > 800:
                        self.x = random.randint(-50,50)
                        self.y = random.randint(500,1200)
                    else:
                        self.x += 1.6
    def draw(self):
        if self.levelcount > 2000:
            if self.anicount % 20 < 10:
                self.image.draw(self.x,self.y)
            else:
                self.image2.draw(self.x,self.y)

    def get_bb(self):
         return self.x-50,self.y-35,self.x+50,self.y+35

    def draw_bb(self):
        if self.levelcount > 2000:
            draw_rectangle(*self.get_bb())


